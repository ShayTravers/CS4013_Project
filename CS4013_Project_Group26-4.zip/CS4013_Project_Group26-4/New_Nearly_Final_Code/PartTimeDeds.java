

public class PartTimeDeds extends PayEmp {
	//i had to divide all these values  by 12 because these employees will be getting paid monthly
	private PayEmp employee;
	private double prsi = 0.04;
    private double payeStand = 0.2;
    private double payeUpper = 0.4;
    private double payeCutOff = 3067;
    private double[] uscRates = {0.005, 0.02, 0.045, 0.08};
    private double[] uscCutOffs = {1001, 1707 , 3690};
    
    
    public PartTimeDeds(PayEmp employee) {
		super();
		this.employee=employee;
}
    private double monthwage() {
    	return getHourlyRate() * getHoursWorked();
    }
    /**
	 * calculates monthly prsi 
	 * @return prsi for the month
	 */
    private double calcPrsi() {
        return (monthwage() * prsi);
    }
    /**
	 * calculates paye upper and lower
	 * @return paye paid for month
	 */
    private double calcPaye() {
        if (monthwage() <= payeCutOff) {
            return monthwage() * payeStand;
        } else {
            double standardTax = payeCutOff * payeStand;
            double upperTax = (monthwage() - payeCutOff) * payeUpper;
            return (standardTax + upperTax);
        }
    }
    /**
     * calculates usc for an employee
     * @return usc for the month
     */
    public double calcUsc() {// when first doing the code i forgot to account for people above 70 and medical card so i added the below logic
		if(eligiableDed()) {// uses boolean method i created below
			if(monthwage()<=1001) {
				return 0;
			}
			return ((monthwage()-1001) *0.02);
		} 
		if(monthwage()<=1083){
			return 0;
		}
		double usc=0;
		double remaining=0;
		
		for(int i =0;i<uscCutOffs.length;i++) {
			if(remaining<=uscCutOffs[i]) {
				usc+=remaining*uscRates[i];
				return usc;
			}
			usc+= uscCutOffs[i]*uscRates[i];
			remaining-=uscCutOffs[i];// here i am subtracting the cut off each time from the remaining and then will calculate usc based off that
		}
		usc+=remaining*uscRates[uscRates.length-1];// here i apply whatever is remaining to the highest possible charge of usc
		return usc/12;
	}
    /**
     * logic to check if someone is eligable for reduced usc
     * @return returns true if they are/false if they are not
     */
	public boolean eligiableDed() {
		if((getAge()>=70 || hasMedicalCard()==true) && monthwage()<=5000 ) {
			return true;
		}
		return false;
	}
	/**
	 * calculates all taxes added together
	 * @return returns total tax
	 */
	public double calculateTotal() {
        return calcPrsi() + calcPaye() + calcUsc();
    }
	/**
	 * gets union fees 
	 * @return union fees for employee
	 */
	public double calcUnion() {
        return getUnion();
    }
	/**
	 * gets health insurance figure
	 * @return
	 */
    public double calcHealth() {
        return getHealth();
    }
    /**
     * adds up total tax and total deductions
     * @return total of both
     */
    public double calcTotalDed() {
        return calcPrsi() + calcPaye() + calcUsc() + calcUnion() + calcHealth();
    }
    /**
     * takes all the deductions away from the months wage
     * @return returns net pay
     */
    public double net() {
    	return monthwage()-calcTotalDed();
    }
    @Override
    //diff tostring because pt has a wage
    /**
     * to string for part time employees
     * @return payslip for part time
     */
	public String toString() {
		return "ID" + employee.getEmployeeId() +"\n" +
				"Name" + employee.getName() + "\n"+
				"Wage" + monthwage() + "\n" +
				"PRSI" + calcPrsi()+"\n"+
			   "PAYE" + calcPaye()+"\n"+
				"USC" + calcUsc() + "\n"+
			   "Total Tax" + calculateTotal() +"\n"+
				"Union Fees" + calcUnion() + "\n"+
			   "Health Insurance" + calcHealth()+ "\n"+
				"Total Deductions" + calcTotalDed() + "\n"+
				"Net Pay" + net();
		
			   
	}
}
