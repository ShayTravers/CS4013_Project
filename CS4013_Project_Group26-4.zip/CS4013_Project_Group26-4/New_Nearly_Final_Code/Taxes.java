 
import java.io.*;
import java.util.List;

public class Taxes extends Payslip{
private double grossSalary;
public double prsi;
public double payeStandard;
public double payeUpper;
public double payeCutOff;
private double[] uscRates;
private double[] uscCutOffs;
private int age;
private boolean medicalCard;

public Taxes(List<PayEmp> ftemps, List<PayEmp> ptemps, double grossSalary) {
    super(ftemps, ptemps); // Call the superclass constructor
    this.grossSalary = grossSalary;
    loadTaxParameters("tax_parameters.csv");
}

private void loadTaxParameters(String filename) {
    try(BufferedReader reader= new BufferedReader(new FileReader(filename))){
    String header= reader.readLine();//skips header because its just title of each column
    String line= reader.readLine();// reads data from each line
    if(line !=null) {
        String[] values= line.split(",");//this line will put commas between each value in our csv file
        this.prsi= Double.parseDouble(values[0]);// turns the strings from the file into doubles for all below. the index indicates where they are in the array
        this.payeStandard= Double.parseDouble(values[1]);
        this.payeUpper= Double.parseDouble(values[2]);
        this.payeCutOff= Double.parseDouble(values[3]);
        // i decied to use a loop for getting both usc rates and their cut offs because there is more than one value 
        String[] uscRatesString= values[4].split(",");
        this.uscRates= new double [uscRatesString.length];
        for( int i=0; i<uscRatesString.length; i++) {
            this.uscRates[i]=Double.parseDouble(uscRatesString[i]);
        }
        String[] uscCutOffsString= values[5].split(",");
        this.uscCutOffs= new double [uscCutOffsString.length];
        for( int i=0; i<uscCutOffsString.length;i ++) {
            this.uscCutOffs[i]= Double.parseDouble(uscCutOffsString[i]);
        } 
    }
    }

    catch(IOException none) {
    System.err.println("an error occurred in the file:" + filename);
    ownValues();// below i have a method that just uses default values in case file does not work
    }
}

private void ownValues() {
    this.prsi=0.04;
    this.payeStandard=0.2;
    this.payeUpper=0.4;
    this.payeCutOff= 36800;
    this.uscRates=new double [] {0.005, 0.02, 0.04, 0.08};
    this.uscCutOffs= new double[] {12012, 13748, 44284};
}

public double getGrossSalary() {
    return grossSalary;
}
public void setGrossSalary(double grossSalary) {
    this.grossSalary=grossSalary;
}

public double calculatePrsi() {
    return grossSalary*0.04;
}

public double calculateUsc() {// when first doing the code i forgot to account for people above 70 and medical card so i added the below logic
    if(eligiableDed()) {// uses boolean method i created below
        if(grossSalary<=12012) {
        return 0;
        }
    return grossSalary *0.02;
    } 
    if(grossSalary<=13000){
        return 0;
    }
    double usc=0;
    double remaining=0;
for(int i =0;i<uscCutOffs.length;i++) {
if(remaining<=uscCutOffs[i]) {
usc+=remaining*uscRates[i];
return usc;
}
usc+= uscCutOffs[i]*uscRates[i];
remaining-=uscCutOffs[i];// here i am subtracting the cut off each time from the remaining and then will calculate usc based off that
}
usc+=remaining*uscRates[uscRates.length-1];// here i apply whatever is remaining to the highest possible charge of usc
return usc;
}
public boolean eligiableDed() {
if(grossSalary<60000||age>=70) {
return true;
}
return false;
}
public double calculatePaye() {
if(grossSalary<= payeCutOff) {
return grossSalary*payeStandard;
}
double standard= payeCutOff * payeStandard;
double upper= (grossSalary-payeCutOff)*payeUpper;
return upper + standard;
}
public double calculateTotal() {
return  calculatePrsi()+calculateUsc()+ calculatePaye();
}
}

