import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
/**
 * shows an employee with a variety of attributes 
 * the attributes are read in from a csv file
 * all these attributes are needing for printing a payslip and calculating deductions etc
 */
public class PayEmp extends CSVParser{
    private PayEmp employee;
	private int employeeId;
    private String name;
	private int age;
	private boolean medicalCard;
	private String type;
	private double union;
	private double healthI;
    private double hoursWorked;
    private double hourlyRate;
    public double annualSalary;
    private String employeeTitle; 
    private double[] payScales;
    /**
     * default constructor, initialises a new employee
     */
	public PayEmp() {
	//getters and setters for info being read in from csv	
	}
	/**
	 * constructor for payemp with all details
	 * @param employeeId unique identifier
	 * @param name their name
	 * @param age their age
	 * @param medicalCard if they have medical card or not
	 * @param type full time or part time
	 * @param union union fees they pay
	 * @param healthI health insurance they pay
	 * @param hoursWorked how many hours they woek
	 * @param hourlyRate what their hourly rate is
	 */
    public PayEmp(int employeeId, String name, int age, boolean medicalCard,
                  String type, double union, double healthI,
                  double hoursWorked, double hourlyRate) {
        this.employeeId = employeeId;
        this.name = name;
        this.age = age;
        this.medicalCard = medicalCard;
        this.type = type;
        this.union = union;
        this.healthI = healthI;
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }
    /**
     * loads pay info from csv. this allows us to assign annual salary to an employee
     * @param fileName the patch where the csv is to be read
     */
    public void loadEmployeeDataFromCSV(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Skip the header or process data
                if (line.startsWith("EmployeeTitle")) {
                    continue; // Skips the header line
                }
    
                String[] data = line.split(",");
                // Assuming the CSV format is: EmployeeTitle, payScale1, payScale2, ..., payScaleN
    
                // Extract employee title
                String employeeTitle = data[0]; // Employee title is in the first column
                double[] payScales = new double[data.length - 1]; // Array to hold pay scales
    
                // Loop through the remaining columns (the pay scales) and parse them as doubles
                for (int i = 1; i < data.length; i++) {
                    payScales[i - 1] = Double.parseDouble(data[i]); // Convert pay scale to double and store it
                }
    
                // Set employee title and pay scales to the current FullTimeDeds object
                this.employeeTitle = employeeTitle; // Set employee title
                this.payScales = payScales; // Set the pay scales
    
                // Optionally set the employee's annual salary
                // In this case, we select the first pay scale as the employee's annual salary
                this.annualSalary = payScales[0]; // Set the employee's annual salary
            }
        } catch (IOException e) {
            System.err.println("Error reading CSV file: " + e.getMessage());
        }
    }
    /**
     * gets reference to payemp instance associated with employee
     * @return the instance representing this employee
     */

    public PayEmp getEmployee() {
        return employee;
    }
    /**
     * gets their title
     * @return title of employee
     */
    public String getEmployeeTitle() {
        return employeeTitle;
    }
    /**
     * gets their id
     * @return their id
     */
	public int getEmployeeId() {
		return employeeId;
	}
	/**
	 * get their name
	 * @return name
	 */
    public String getName() {
        return name;
    }
    /**
     * gets employees age
     * @return their age
     */
	public int getAge() {
		return age;
	}
	/**
	 * gets payscales associated with an employee
	 * @return array of payscales for employee
	 */
    public double[] getPayScales() {
        return payScales;
    }
    /**
     * retrieves annual salary for employee
     * @return their annual salary 
     */
    public double getAnnualSalary() {
        return annualSalary;
    }
    /**
     * checks if employee has a medical card
     * @returntrue if they have one, false if not
     */
	public boolean hasMedicalCard() {
		return medicalCard;
	}
	/**
	 * sets employee id
	 * @param employeeId integer which will be the value of their id
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId=employeeId;
	}
	/**
	 * sets employees age
	 * @param age sets as integer
	 */
	public void setAge(int age) {
		this.age=age;
	}
	/**
	 * sets if they have medical card or not
	 * @param medicalCard true/false for medical card
	 */
	public void setMedicalCard(boolean medicalCard) {
		this.medicalCard=medicalCard;
	}
	/**gets if they are full/part time
	 * 
	 * @return FT or PT
	 */
	public String getType() {
		return type;
	}
	/**
	 * sets if they are full or part time
	 * @param type
	 */
	public void setType(String type) {
		this.type=type;
	}
	/**
	 * gets their union fee amount
	 * @return union fee amount
	 */
	public double getUnion() {
		return union;
	}
	/**
	 * sets their union fee 
	 * @param union amount they will pay is set
	 */
	public void setUnion(double union) {
		this.union=union;
	}
	/**
	 * gets how much health insurance they will pay
	 * @return amount they will pay
	 */
	public double getHealth() {
		return healthI;
	}
	/**
	 * sets health insurance to double value
	 * @param healthI sets health insurance to a double amount
	 */
	public void setHealth( double healthI) {
		this.healthI=healthI;
	}
	/**
	 * retrieves hourly rate
	 * @return
	 */
    public double getHourlyRate() {
        return hourlyRate;
    }
    /**
     * sets what their hourly rate is
     * @param hourlyRate 
     */
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }
    /**
     * gets how many hours an employee has worked
     * @return how many hours worked (double)
     */
    public double getHoursWorked() {
        return hoursWorked;
    }
    /**
     * sets the amount of hours worked
     * @param hoursWorked sets amount worked as a double value 
     */
    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }


}

