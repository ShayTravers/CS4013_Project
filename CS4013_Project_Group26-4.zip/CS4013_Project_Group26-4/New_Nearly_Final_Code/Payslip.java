

import java.time.*;

/**
 * This class basically just manages payslips for employees
 * adds/takes away a day if neccessary (if its a saturday or sunday)
 * generates a different payslip depending on if employee if full or part time
 */
import java.util.List;
public class Payslip {
	private LocalDate currentDate;
    private LocalDate payDay;
    private List<PayEmp> fullTimeEmployees;
    private List<PayEmp> partTimeEmployees;
    /**
     * constructs Payslip object with lists of full and part time employees
     * @param ftemps list of full time employees
     * @param ptemps list of part time employees
     */
    public Payslip(List<PayEmp> ftemps, List<PayEmp> ptemps) {
    this.currentDate= LocalDate.now();
    this.fullTimeEmployees=ftemps;
    this.partTimeEmployees=ptemps;
    }
    //so what this does is it just takes the month and year 
    //and changes the day but keeps the same year an month of whatever current date is
    /**
     * sets pay day to 25th of the month
     */
    public void setPayDay() {
        payDay=currentDate.withDayOfMonth(25);
    }
    /**
     * method to return day of week for payday
     * @return day of week for payday
     */
    public DayOfWeek day() {
        return payDay.getDayOfWeek();
    }
    /**
     * retrieves list of full time employees
     * @return list of full time employees
     */
    public List<PayEmp> getFullTimeEmployees() {
        return fullTimeEmployees;
    }
    /**
     * retrieves list of part time employees
     * @return list of part time employees
     */
    public List<PayEmp> getPartTimeEmployees() {
        return partTimeEmployees;
    }
    // this is the method i chose to decide which payslip gets printed
    //If the employee is a full time employee they will get one payslip and vice versa
    //I also used my checkDay() logic from and printed messages if it was Saturday/Sunday
    /**
     * Prints payslip for employee based on checkDay
     * outputs different message depending on the day
     * @param employee employee whos payslip is printed
     */
    private void printPs(PayEmp employee) {
        checkDay(day());
        if(LocalDate.now()==payDay) {
            String payslipFT= generatePs(employee);
            //need to add payslip to array of payslips
        }else if(payDay.getDayOfWeek()==DayOfWeek.SATURDAY){
            System.out.println("Since the 25th is a Saturday, you were paid yesterday");
        }else if(payDay.getDayOfWeek()==DayOfWeek.SUNDAY) {
            System.out.println("Since the 25th is a Sunday, you will be paid tomorrow");
        }else {
            System.out.println("Today is not you payday. If you have any issues please contact HR");
       }
     } 
    
    //i created this method to generate two different types of payslip depending on if the employee is pt/ft
    /**
     * generates a payslip depending on what type of employee it is
     * @param employee
     * @return full/part time payslip
     */
    private String generatePs(PayEmp employee) {
    	if ("FT".equals(employee.getType())) {
            FullTimeDeds fullTimeDeds = new FullTimeDeds(employee);
            return fullTimeDeds.toString();
        } else {
            PartTimeDeds partTimeDeds = new PartTimeDeds();
            return partTimeDeds.toString();
        }
          
    }
    
    //this is the method i will be using to check if the day falls on a saturday/sunday
    //it will add or take away a day based on a result
    /**
     * adjusts payday if it falls on Sat/Sun (adds/takes away a day to payday)
     * @param day
     */
    private void checkDay(DayOfWeek day) {
    if(day==DayOfWeek.SATURDAY) {
        payDay=payDay.minusDays(1);
    }
    else if(day==DayOfWeek.SUNDAY) {
        payDay=payDay.plusDays(1);
    }else {
        payDay=payDay.withDayOfMonth(25);
    }
  }
 
} 