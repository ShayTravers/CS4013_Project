// HRUser.java
import java.util.Scanner;

public class HRUser extends User {

    public HRUser(String userId, String password, String name) {
        super(userId, password, name);
    }

    @Override
    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Promote Employee");
        System.out.println("Select an option:");

        //if HRUser enters "1" they must follow by entering the employee's userId that they wish to promote
        if (scanner.nextLine().equals("1")) {
            System.out.println("Enter employee user ID: ");
            String employeeId = scanner.nextLine();
            // employeeID links to userId of an employee
            Employee employee = EmployeeDatabase.getEmployeeById(employeeId);
        
            if (employee instanceof FullTimeEmployee) {
                promoteEmployee((FullTimeEmployee) employee);
            } else {
                System.out.println("Employee must be full-time to be promoted.");
            }
        }
    }

    public void promoteEmployee(FullTimeEmployee employee) {
        Scanner scanner = new Scanner(System.in);
        //Details of employee name and pay grade
        System.out.println("Promoting employee: " + employee.name);
        System.out.println("Current Pay Grade: " + employee.getPayGrade());
        //HRUser enters new Paygrade
        System.out.println("Enter new Pay Grade: ");
        int newPayGrade = scanner.nextInt();
        //Details of salary
        System.out.println("Current Salary: " + employee.getAnnualSalary());
        //HRUser enters new salary
        System.out.println("Enter new Salary: ");
        double newSalary = scanner.nextDouble();
        //HRUser confirms promotion
        System.out.println("Are you sure you want to promote " + employee.name + "? (yes/no)");
        String response = scanner.nextLine();

        if (response.equalsIgnoreCase("yes")) {
            //promote method for employee is used and the employee must confirm the promotion
            employee.promote(newPayGrade, newSalary);
            System.out.println(employee.name + " has been sent a promotion confirmation request.");
        } else {
            System.out.println("Promotion cancelled.");
        }
    }
}
