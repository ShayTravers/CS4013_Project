
import java.io.*;
import java.util.*;
/**
 * this class just reads in employee data i need for calculating their taxes and deductions
 * @author Fionn
 * @version 2-12-24
 */
public class PayReader extends PayEmp {
// i made this to read in employee data ill need for tax/deds
	//i made these arrays to separate employees in ft/pt
		private List<PayEmp> ftemps;
		private List<PayEmp> ptemps;
	/**
	 * constructor for my PayReader object. Initilises two lists for Part and full time
	 */
	public PayReader() {
		ftemps= new ArrayList<>();
		ptemps= new ArrayList<>();
	} 	 	
	//resd in my data
		String file = "path/to/taxdeds.csv";
		/**
		 * Reads all the data i need from a csv in order to calculate tax. 
		 * @param file: this is the patch csv reads file from
		 * @return list of payemp objects read from this file
		 */
		public List<PayEmp> empdata (String file){
			List<PayEmp> emps = new ArrayList<>();
			try( BufferedReader reader= new BufferedReader(new FileReader( file))){
				String line;
				reader.readLine();
				while ((line=reader.readLine())!=null){
					String[] vals= line.split(",");
					PayEmp employee = new PayEmp(); 
	                employee.setEmployeeId(Integer.parseInt(vals[0]));
	                employee.setAge(Integer.parseInt(vals[1]));
	                employee.setMedicalCard(Boolean.parseBoolean(vals[2]));
	                employee.setType(vals[3]);
	                employee.setHealth(Double.parseDouble(vals[4]));	
	                employee.setUnion(Double.parseDouble(vals[5]));
	                emps.add(employee);
	                
	                //sorting
	                if("FT".equals(employee.getType())) {
	                	 ftemps.add(employee);
	                }else if("PT".equals(employee.getType())) {
	                	ptemps.add(employee);
	                	
	                }
			}
		}
			catch(IOException f) {
				System.err.println("Error reading the file: " + f.getMessage());
			}
			return emps;
	}
		
		/**
		 *  just returns list of full time employees
		 * @return list of full time employees
		 */
		public List<PayEmp> getFtEmps() {
	        return ftemps;
	    }
		
		/**
		 * just returns list of part time employees
		 * @return list of part time employees
		 */
	    public List<PayEmp> getPtEmps() {
	        return ptemps;
	    }
}
		
		
		
