import java.io.*;
import java.util.*;

public class CSVParser {

    public static Map<Integer, Employee> parseEmployeeData(String filename, Map<Integer, Payslip> payslipData) {
        Map<Integer, Employee> employees = new HashMap<>();
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String header = reader.readLine();
            String line;
            
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                
                int employeeId = Integer.parseInt(values[0].trim());
                String name = values[1].trim();
                String type = values[2].trim();
                boolean hasMedicalCard = Boolean.parseBoolean(values[3].trim());
                int health = Integer.parseInt(values[4].trim());
                int union = Integer.parseInt(values[5].trim());

                if (values.length > 3) {
                    String role = values[3];
                } else {
                    System.out.println("Not enough columns in this row.");
                }

                Payslip payslip = payslipData.get(employeeId);
                if (payslip == null) {
                    System.err.println("No payslip found for employee with ID: " + employeeId);
                    continue;
                }

                Employee employee = null;
                if ("FullTime".equalsIgnoreCase(type)) {
                    employee = new FullTimeEmployee("userId", "password", name, new ArrayList<>());
                } else if ("PartTime".equalsIgnoreCase(type)) {
                    employee = new PartTimeEmployee("userId", "password", name, 20.00, new ArrayList<>());
                }
                
                if (employee != null) {
                    employee.payslips.add(payslip);
                    employees.put(employeeId, employee);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading employee data file: " + filename);
            e.printStackTrace();
        }
        
        return employees;
    }

    public static Map<Integer, Payslip> parsePayslipData(String filename) {
        Map<Integer, Payslip> payslips = new HashMap<>();
        List<PayEmp> fullTimeEmployees = new ArrayList<>();
        List<PayEmp> partTimeEmployees = new ArrayList<>();
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String header = reader.readLine(); // Skips the header
            String line;
            
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                int employeeId = Integer.parseInt(values[0].trim());
                String name = values[1].trim();
                double ageGroup = Double.parseDouble(values[2].trim());
                boolean medicalCard = values[3].trim().equals("1");
                String type = values[4].trim();
                double health = Double.parseDouble(values[5].trim());
                double union = Double.parseDouble(values[6].trim());
                double hoursWorked = Double.parseDouble(values[7].trim());
                double hourlyRate = Double.parseDouble(values[8].trim());
    
                PayEmp payEmp = new PayEmp(
                    Integer.parseInt(values[0].trim()),     
                    values[1].trim(),                       
                    Integer.parseInt(values[2].trim()),     
                    Boolean.parseBoolean(values[3].trim()), 
                    values[4].trim(),                       
                    Double.parseDouble(values[5].trim()),   
                    Double.parseDouble(values[6].trim()),   
                    Double.parseDouble(values[7].trim()),   
                    Double.parseDouble(values[8].trim())    
                );
    
                payEmp.setType("FullTime".equalsIgnoreCase(values[2].trim()) ? "FT" : "PT");
    
                if ("FullTime".equalsIgnoreCase(values[4].trim())) {
                    fullTimeEmployees.add(payEmp);
                } else {
                    partTimeEmployees.add(payEmp);
                }
    
                // Now create the Payslip object for each employee individually
                Payslip payslip = new Payslip(new ArrayList<>(fullTimeEmployees), new ArrayList<>(partTimeEmployees));
                payslip.setPayDay();
                payslips.put(employeeId, payslip);
    
                // Clear the lists for the next iteration
                fullTimeEmployees.clear();
                partTimeEmployees.clear();
            }
        } catch (IOException e) {
            System.err.println("Error reading the payslip data file : " + filename);
            e.printStackTrace();
        }
        
        return payslips;
    }
    

    public static void main(String[] args) {
       
        Map<Integer, Payslip> payslipData = parsePayslipData("taxdeds.csv");
        Map<Integer, Employee> employeeData = parseEmployeeData("TitlesAndPay.csv", payslipData);

        
        for (Employee employee : employeeData.values()) {
            for (Payslip payslip : employee.payslips) {
                for (PayEmp emp : payslip.getFullTimeEmployees()) {
                    payslip.printPs(emp);  
                }
                for (PayEmp emp : payslip.getPartTimeEmployees()) {
                    payslip.printPs(emp); 
                }
            }
        }
    }
}
