import java.util.ArrayList;
import java.util.Scanner;

public class LoginManager { 
    private ArrayList<User> users; // stores the list of users who can log in

    public LoginManager() {
        users = new ArrayList<>(); // initializes the users list as an empty arraylist
        users.add(new PartTimeEmployee("pt1", "pass", "Bob", 15, null)); // adds a part-time employee user to the list
        users.add(new HRUser("hr1", "pass", "Sarah")); // adds an hr user to the list

    public void mainMenu() {
        Scanner scanner = new Scanner(System.in); // creates a scanner object for user input
        System.out.print("Username: "); // prompts the user to enter their username
        String username = scanner.nextLine(); // reads the username entered by the user
        System.out.print("Password: "); // prompts the user to enter their password
        String password = scanner.nextLine(); // reads the password entered by the user

        User user = authenticate(username, password); // attempts to authenticate the user using the provided credentials
        if (user != null) { // checks if the user is authenticated
            user.showMenu(); // shows the menu specific to the authenticated user
        }
    }

    public User authenticate(String username, String password) {
        for (User user : users) { // iterates through all users in the list
            if (user.getUserId().equals(username) && user.authenticate(password)) { // checks if username and password match
                return user; // returns the authenticated user if credentials match
            }
        }
        return null; // returns null if no matching user is found
    }
}
