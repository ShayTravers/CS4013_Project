import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
public class PartTimeEmployee extends Employee {
    private ArrayList<PayClaim> payClaims;
    private double hourlyRate;
    private double hoursWorked;
    private double incomeTax;
    private double prsi;
    private double usc;
    private double netPay = hourlyRate*hoursWorked;

    public PartTimeEmployee(String userId, String password, String name, double hourlyRate, ArrayList<Payslip> payslips) { 
        super(userId, password, name, payslips);
        this.payClaims = new ArrayList<>();
        this.hourlyRate = hourlyRate; 
    }

    // Getters and setters
    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public void submitPayClaim(LocalDate dateOfSubmission, double hoursWorked) {
        LocalDate currentDate = LocalDate.now();
        int year = currentDate.getYear();
        int month = currentDate.getMonthValue();
        boolean alreadySubmitted;


        //the 1st of the current month
        LocalDate firstOfMonth = LocalDate.of(year, month, 1);

        //DayOfWeek.FRIDAY.getValue() always returns 5 as 5 represents friday
        //date.getDayOfWeek().getValue() gets the value of the actual day of the week, e.g. if it is a saturday it returns 6
        //therefore for the example of saturday, daysToFirstFriday = (5 - 6 + 7) % 7 which is 6. If the first is saturday then 6 days until friday
        int daysToFirstFriday = (DayOfWeek.FRIDAY.getValue() - firstOfMonth.getDayOfWeek().getValue() + 7) % 7;

        LocalDate firstFriday = firstOfMonth.plusDays(daysToFirstFriday);
        LocalDate secondFriday = firstFriday.plusDays(7);
        
        
        PayClaim lastClaim = payClaims.isEmpty() ? null : payClaims.get(payClaims.size() - 1);
        alreadySubmitted = false;

        if (lastClaim != null) {
            LocalDate lastClaimDate = lastClaim.getDateOfSubmission();
            // Check if the last claim was within the same month and before the second Friday
            alreadySubmitted = lastClaimDate.getYear() == year &&
                               lastClaimDate.getMonthValue() == month &&
                               !lastClaimDate.isAfter(secondFriday);
        }

        if ((dateOfSubmission.isEqual(secondFriday) || dateOfSubmission.isBefore(secondFriday)) && !alreadySubmitted) {
            PayClaim payclaim = new PayClaim(dateOfSubmission, hoursWorked);
            payClaims.add(payclaim);
            System.out.println("Payclaim added successfully.");
        } else {
            System.out.println("Payclaim failed to submit: Date past second Friday of the month.");
        }
    }

    public ArrayList<PayClaim> getPayClaims() {
        return payClaims;
    }

    public double getIncomeTax() {
        return incomeTax;
    }

    public double getPrsi() {
        return prsi;
    }

    public double getUsc() {
        return usc;
    }

    @Override
    public String toString() {
        return "Part-Time Employee [Name: " + name +
         ", Hourly Rate: " + hourlyRate + "]";
    }
} 