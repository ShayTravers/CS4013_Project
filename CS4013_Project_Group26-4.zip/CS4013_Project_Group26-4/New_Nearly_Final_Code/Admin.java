// Admin.java
import java.util.Scanner;

public class Admin extends User {

    public Admin(String userId, String password, String name) {
        super(userId, password, name);
    }

    @Override
    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Add New Employee");
        System.out.println("Select an option:");
        //if Admin enters "1" they can add an employee to the database
        if (scanner.nextLine().equals("1")) {
            addNewEmployee();
        }
    }

    public void addNewEmployee() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Employee User ID:");
        String employeeId = scanner.nextLine();

        System.out.println("Enter Employee Password:");
        String employeePassword = scanner.nextLine();

        System.out.println("Enter Employee Name:");
        String employeeName = scanner.nextLine();

        System.out.println("Enter Employee Type (1 for Full-Time, 2 for Part-Time):");
        int employeeType = scanner.nextInt();

        if (employeeType == 1) {
            //Full-time
            System.out.println("Enter Employee Annual Salary:");
            double annualSalary = scanner.nextDouble();
            
            System.out.println("Enter Employee Pay Grade:");
            int payGrade = scanner.nextInt();
            
            //creates new full time employee and adds it to the employee database
            FullTimeEmployee newEmployee = new FullTimeEmployee(employeeId, employeePassword, employeeName, null);
            EmployeeDatabase.addEmployeeToDatabase(newEmployee);
            System.out.println("Full-Time employee successfully added.");
        } else if (employeeType == 2) {
            //Part-time
            System.out.println("Enter Employee Hourly Rate:");
            double hourlyRate = scanner.nextDouble();
            
            //creates new part time employee and adds it to the employee database
            PartTimeEmployee newEmployee = new PartTimeEmployee(employeeId, employeePassword, employeeName, hourlyRate, null);
            EmployeeDatabase.addEmployeeToDatabase(newEmployee);
            System.out.println("Part-Time employee successfully added.");
        } else {
            System.out.println("Invalid choice.");
        }
    }
}
