// User.java
public abstract class User{
    
    public String userId;
    public String password;
    public String name;

    public User(String userId, String password, String name) {
        this.userId = userId;
        this.password = password;
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }
    
    public String getName(){
        return name;
    }
    
    public boolean authenticate(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    public void showMenu(){
        
    }
    
}
