import java.util.ArrayList;

public class EmployeeDatabase {
    private static ArrayList<Employee> employees = new ArrayList<>();

    // Add an employee to the database
    public static void addEmployeeToDatabase(Employee employee) {
        employees.add(employee);
    }

    // Get an employee by their userId (used in HRUser promotion)
    public static Employee getEmployeeById(String userId) {
        for (Employee employee : employees) {
            if (employee.getUserId().equals(userId)) {
                return employee;
            }
        }
        return null; // Return null if no employee with given userId is found
    }
}
