import java.util.ArrayList;

public class FullTimeEmployee extends Employee {

    private double annualSalary; // stores te yerly earnings of the employe which is used as the basis for calculating deductions and net salary
    private int payGrade; // represents the employes position in the pay scale used to determine eligibility for promotions and salary increases
    private boolean isPromoted; // tracks whether the employe has been promoted hlping to differentiate between newly hired and promted employees
    private double incomeTax; // stores the calculted income tax amont (20% of anual salary) which is deducted from the gross salary
    private double prsi; // repesents the Pay-Related Social Insurance (4% of annual salary) a mandatory deduction for social welfare programs
    private double usc; // holds the Universal Social Charge (5% of annual salary) another tax deduction aplied to all income levels

    // constructor for FullTimeEmployee
    
    public FullTimeEmployee(String userId, String password, String name, ArrayList<Payslip> payslips) { // constructor initializes FullTimeEmployee with userId password and name 
        super(userId, password, name, payslips); // calls the parent Employee class constructor to initialize shared attributes like userId passwor and name
        this.isPromoted = false; // initializes the promotion stats as false indicating the employee hasnt been promoted yet
        this.annualSalary = 0.0; // here i initialize default salary this can be updated later£ using setAnnualSalary()
        this.payGrade = 1;  // initializes the default pay grade to 1 representing the base level for new employees
        calculateDeductions();  // calculates initial diductions (e.g., incomeTax, PRSI, USC) based on the default salery of 0.0
    }
    
    public double getAnnualSalary() { // getter for the annual salary
        return annualSalary; // returns the current pay grade of the employe
    }

    public void setAnnualSalary(double annualSalary) { // setter for the annual salary
        this.annualSalary = annualSalary; // updates the annual salary attribute with the provided value
        calculateDeductions(); // recalculates deductions based on the updated salary
    }

    public int getPayGrade() { // getter for the pay grade
        return payGrade; // returns the current pay grade of the employe
    }

    public void setPayGrade(int payGrade) { // setter for the pay grade
        this.payGrade = payGrade; // updates the pay grade attribute with the provided valueecl
    }

    public boolean isPromoted() {  // getter for promotion status
        return isPromoted; // returns true if the employee has been promoted, false otherwize
    }
    
    public double getIncomeTax() { // getter for income tax
        return incomeTax; // returns the calculated income tax value
    }
    
    public double getPrsi() { // getter for prsi (pay-related social insurance)
        return prsi; // returns the calculated prsi value
    }

    public double getUsc() { // getter for usc (universal social charge)
        return usc; // returns the calculated usc value
    }

    public void promote(int newPayGrade, double newSalary) { // this method promotes employe
        if (newPayGrade > this.payGrade) { // checks if the new pay grade is higher than the current one
            this.payGrade = newPayGrade; // updates pay grade and annual salary to the new values
            this.annualSalary = newSalary;
            this.isPromoted = true; // marks the employe as promoted
            calculateDeductions(); // recalculates deductions based on the new salary
            System.out.println("Employee " + getName() + " has been promoted to pay grade " + newPayGrade); // prints a confirmation mesage showing the promotion details
        } else {
            System.out.println("Invalid promotion. New pay grade must be higher than current pay grade.");
        } // prints an error mesage if the promotion is invalid
    }
   
    private void calculateDeductions() { // private method to calculate salary deductons
        this.incomeTax = annualSalary * 0.2; // flat 20% income tax rate
        this.prsi = annualSalary * 0.04;     // 4% PRSI rate
        this.usc = annualSalary * 0.05;      // 5% USC rate
    }

    public double getNetSalary() { // calculate and return the net salary
        return annualSalary - (incomeTax + prsi + usc); // substracts all deductions (income tax, prsi, usc) from the annual salary
    }

    @Override // overrides the toString() method to provide a detailed summary of the employee's details
    public String toString() {
        return super.toString() + "\\nFull-Time Employee Details: " +
                "\\nAnnual Salary: " + annualSalary +
                "\\nPay Grade: " + payGrade +
                "\\nPromotion Status: " + (isPromoted ? "Promoted" : "Not Promoted") +
                "\\nIncome Tax: " + incomeTax +
                "\\nPRSI: " + prsi +
                "\\nUSC: " + usc +
                "\\nNet Salary: " + getNetSalary();
    } // combines parent class details with fulltimeemployee-specific details
}