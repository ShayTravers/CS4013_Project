import java.time.LocalDate;

public class PayClaim {
    private LocalDate dateOfSubmission;
    private double hoursWorked;

    public PayClaim(LocalDate dateOfSubmission, double hoursWorked) {
        this.dateOfSubmission = dateOfSubmission;
        this.hoursWorked = hoursWorked;
    }
}