
/**
 * this class manages pay deductions for full time employees
 * this includes taxes and deductions (union fees and health insurance)
 * the class also extends PayEmp
 * deductions calculated monthly
 */
public class FullTimeDeds extends PayEmp {
	//i assume these stay fixed. In the methods i divide all by 12 seeing as theyre getting payed monthly
		private PayEmp employee;
	    private double prsi = 0.04;
	    private double payeStand = 0.2;
	    private double payeUpper = 0.4;
	    private double payeCutOff = 36800;
	    private double[] uscRates = {0.005, 0.02, 0.045, 0.08};
	    private double[] uscCutOffs = {12012, 20484, 44284};
	    
	    /**
	     * constructs a FullTimeDeds object with PayEmp employee
	     * @param employee: represents employee (PayEmp) for which the deductions are being calculated
	     */
	    public FullTimeDeds(PayEmp employee) {
	    		super();
	    		this.employee=employee;
	    }
	    
	    	/**
	    	 * calculates monthly prsi 
	    	 * @return prsi for the month
	    	 */
	    	private double calcPrsi() {
		        return (employee.getAnnualSalary() * prsi)/12;
		    }
	    	/**
	    	 * calculates paye upper and lower
	    	 * @return paye paid for month
	    	 */
		    private double calcPaye() {
		    	double annualSalary= employee.getAnnualSalary();
		        if (annualSalary <= payeCutOff) {
		            return annualSalary * payeStand;
		        } else {
		            double standardTax = payeCutOff * payeStand;
		            double upperTax = (annualSalary - payeCutOff) * payeUpper;
		            return (standardTax + upperTax)/12;
		        }
		    }
		    /**
		     * calculates usc for an employee
		     * @return usc for the month
		     */
		    public double calcUsc() {// when first doing the code i forgot to account for people above 70 and medical card so i added the below logic
		    	double annualSalary= employee.getAnnualSalary();
		    	if(eligiableDed()) {// uses boolean method i created below
					if(annualSalary<=12012) {
						return 0;
					}
					return ((annualSalary-12012) *0.02)/12;
				} 
				if(annualSalary<=13000){
					return 0;
				}
				double usc=0;
				double remaining=0;
				
				for(int i =0;i<uscCutOffs.length;i++) {
					if(remaining<=uscCutOffs[i]) {
						usc+=remaining*uscRates[i];
						return usc;
					}
					usc+= uscCutOffs[i]*uscRates[i];
					remaining-=uscCutOffs[i];// here i am subtracting the cut off each time from the remaining and then will calculate usc based off that
				}
				usc+=remaining*uscRates[uscRates.length-1];// here i apply whatever is remaining to the highest possible charge of usc
				return usc/12;
			}
		    /**
		     * logic to check if someone is eligable for reduced usc
		     * @return returns true if they are/false if they are not
		     */
			public boolean eligiableDed() {
				if((getAge()>=70 || hasMedicalCard()) && employee.getAnnualSalary()<=60000 ) {
					return true;
				}
				return false;
			}
			/**
			 * calculates all taxes added together
			 * @return returns total tax
			 */
			public double calculateTotal() {
		        return calcPrsi() + calcPaye() + calcUsc();
		        
		    }
			/**
			 * gets union fees 
			 * @return union fees for employee
			 */
			public double calcUnion() {
		        return getUnion();
		    }
			/**
			 * gets health insurance figure
			 * @return
			 */
		    public double calcHealth() {
		        return getHealth();
		    }
		    /**
		     * adds up total tax and total deductions
		     * @return total of both
		     */
		    public double calcTotalDed() {
		        return calcPrsi() + calcPaye() + calcUsc() + calcUnion() + calcHealth();
		    }
		    /**
		     * takes all the deductions away from the annual salary
		     * @return returns net pay
		     */
		    public double net() {
		    	return annualSalary-calcTotalDed();
		    }
		    /**
		     * puts all the above info into a string(payslip)
		     * @return the string(payslip)
		     */
			public String toString() {
				return 	"ID" + employee.getEmployeeId() +"\n" +
						"Name" + employee.getName() + "\n"+
						"PRSI" + calcPrsi()+"\n"+
					   "PAYE" + calcPaye()+"\n"+
						"USC" + calcUsc() + "\n"+
					   "Total Tax" + calculateTotal() +"\n"+
						"Union Fees" + calcUnion() + "\n"+
					   "Health Insurance" + calcHealth()+ "\n"+
						"Total Deductions" + calcTotalDed() + "\n"+
						"Net Pay" + net();
					   
			}
	    
	    
	  
	    }
}




	


