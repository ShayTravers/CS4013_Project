import java.util.ArrayList;

public abstract class Employee extends User {
    protected ArrayList<Payslip> payslips;

    public Employee(String userId, String password, String name, ArrayList<Payslip> payslips) {
        super(userId, password, name);
        this.payslips = (payslips == null) ? new ArrayList<>() : payslips;
    }

    public String toString() {
        return "ID : " + userId + 
                "\nEmployee Name : " + name +
                "\nNumber of Payslips : " + (payslips != null ? payslips.size() : 0);
    }
}