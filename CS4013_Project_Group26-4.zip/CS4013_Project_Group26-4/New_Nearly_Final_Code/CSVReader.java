
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {
    public static void main(String[] args) {
        String path = "path_to_your_file/TitlesAndPayCSVFile(Sheet1).csv"; // Replace with the actual file path
        String line = "";

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            while ((line = br.readLine()) != null) {
                String[] values = line.split(","); // Assuming the CSV uses commas as separators
                // You can process each line here. For example, print each parsed value.
                for (String value : values) {
                    System.out.print(value + " ");
                }
                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
